// assembly/game-of-life.ts
// Conway's Game of Life em AssemblyScript (versão simples e robusta)

// ----------------------------------------------------------------------
// Constantes de grelha
// ----------------------------------------------------------------------

export const WIDTH: i32 = 120;
export const HEIGHT: i32 = 80;

// Número total de células
const SIZE: i32 = WIDTH * HEIGHT;

// ----------------------------------------------------------------------
// Memória: dois buffers (estado atual e próximo estado)
// ----------------------------------------------------------------------

// memory.data devolve um ponteiro (usize) para um bloco de SIZE bytes.
// Guardamos primeiro em variáveis usize, depois exportamos como i32
// para o JavaScript/React usar.

const CELLS_PTR_USIZE: usize = memory.data(SIZE);
const NEXT_PTR_USIZE: usize  = memory.data(SIZE);

export const cellsPtr: i32 = CELLS_PTR_USIZE as i32;
export const nextPtr: i32  = NEXT_PTR_USIZE  as i32;

// ----------------------------------------------------------------------
// Funções auxiliares internas
// ----------------------------------------------------------------------

// Índice 1D a partir de coordenadas (x, y)

function idx(x: i32, y: i32): i32 {
    return y * WIDTH + x;
}

// Conta vizinhos vivos de uma célula, com "wrap around" nas bordas
function countNeighbors(x: i32, y: i32): i32 {
    let count: i32 = 0;

    for (let dy = -1; dy <= 1; dy++) {
        for (let dx = -1; dx <= 1; dx++) {
            if (dx == 0 && dy == 0) continue;

            let nx = x + dx;
            let ny = y + dy;

            // wrap horizontal
            if (nx < 0) nx = WIDTH - 1;
            else if (nx >= WIDTH) nx = 0;

            // wrap vertical
            if (ny < 0) ny = HEIGHT - 1;
            else if (ny >= HEIGHT) ny = 0;

            const i = idx(nx, ny);
            const v: u8 = load<u8>(cellsPtr + i);
            count += v as i32;
        }
    }

    return count;
}

// ----------------------------------------------------------------------
// API exportada para o JavaScript
// ----------------------------------------------------------------------

// Inicializa a grelha com um padrão visível
export function init(): void {
    for (let y = 0; y < HEIGHT; y++) {
        for (let x = 0; x < WIDTH; x++) {
            const i = idx(x, y);

            // padrão tipo "xadrez"
            let alive: u8 = ((x + y) & 1) == 0 ? 1 as u8 : 0 as u8;

            // linha do meio toda viva
            if (y == HEIGHT / 2) alive = 1;

            store<u8>(cellsPtr + i, alive);
        }
    }
}

// Avança uma geração do jogo da vida
export function step(): void {
    // 1) calcular próximo estado em NEXT_PTR_USIZE
    for (let y = 0; y < HEIGHT; y++) {
        for (let x = 0; x < WIDTH; x++) {
            const i = idx(x, y);
            const state: u8 = load<u8>(cellsPtr + i);
            const neighbors = countNeighbors(x, y);

            let nextState: u8 = state;

            if (state == 1) {
                // célula viva
                if (neighbors < 2 || neighbors > 3) nextState = 0;
            } else {
                // célula morta
                if (neighbors == 3) nextState = 1;
            }

            store<u8>(nextPtr + i, nextState);
        }
    }

    // 2) copiar nextPtr → cellsPtr (commit da geração)
    for (let i = 0; i < SIZE; i++) {
        const v: u8 = load<u8>(nextPtr + i);
        store<u8>(cellsPtr + i, v);
    }
}